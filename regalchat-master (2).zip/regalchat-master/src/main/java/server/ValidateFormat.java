package server;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

class ValidateFormat {
    private static final Pattern VALID_EMAIL_ADDRESS_REGEX =
            Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", Pattern.CASE_INSENSITIVE);
    private static final Pattern VALID_USERNAME_REGEX =
            Pattern.compile("^[A-Z0-9._-]{3,32}$", Pattern.CASE_INSENSITIVE);
    private static final Pattern VALID_PASSWORD_REGEX =
            Pattern.compile("(?=^.{8,32}$)((?=.*\\d)|(?=.*\\W+))(?![.\\n])(?=.*[A-Z])(?=.*[a-z]).*$");

    private static boolean validate(Pattern pattern, String input) {
        Matcher matcher = pattern.matcher(input);
        return matcher.find();
    }

    public static boolean username(String username) {
        return validate(VALID_USERNAME_REGEX, username);
    }

    public static boolean password(String password) {
        return validate(VALID_PASSWORD_REGEX, password);
    }

    public static boolean[] password(String password1, String password2) {
        boolean[] bool = new boolean[2];
        bool[0] = password(password1);
        bool[1] = password1.equals(password2);
        return bool;
    }

    public static boolean email(String email) {
        return validate(VALID_EMAIL_ADDRESS_REGEX, email);
    }

    public static boolean[] registration(String username, String email, String password1, String password2) {
        boolean[] passBool = password(password1, password2);
        return new boolean[]{username(username), email(email), passBool[0], passBool[1]};
    }
}