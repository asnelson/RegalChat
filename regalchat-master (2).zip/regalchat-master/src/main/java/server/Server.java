package server;

import server.database.JDBCOperations;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.SQLException;
import java.sql.Connection;
import java.util.*;

public class Server {

    // -- the port number used for client communication
    private static final int CT_PORT = 8000;
    // -- assign each client connection an ID. Just increment for now
    private int nextId = 0;
    // -- the socket that waits for client connections
    private ServerSocket serverSocket;
    // -- list of active client threads by ID number
    private Vector<ConnectionThread> clientConnections;
    // -- connection to database
    public static Connection dbCon;
    // -- map of users to login status.
    private Map<Integer, Boolean> validSessions = new HashMap<>();


    private Server() throws SQLException {

        // -- construct database connection
        dbCon = JDBCOperations.getConnection();

        // -- construct the list of active client threads
        clientConnections = new Vector<>();

        // -- listen for incoming connection requests
        listen();
    }

    public static void main(String args[]) throws SQLException {
        // -- instantiate the server anonymously
        //    no need to keep a reference to the object since it will run in its own thread
        new Server();

    }

    private int getPort() {
        return CT_PORT;
    }

    private void peerConnection(Socket socket) {
        // -- when a client arrives, create a thread for their communication
        ConnectionThread connection = new ConnectionThread(nextId, socket, this);

        // -- add the thread to the active client threads list
        clientConnections.add(connection);

        // -- start the thread
        connection.start();

        // -- place some text in the area to let the server operator know
        //    what is going on
        System.out.println("SERVER: connection received for id " + nextId + "\n");
        ++nextId;
    }

    // -- called by a ServerThread when a client is terminated
    void removeID(int id) {
        // -- find the object belonging to the client thread being terminated
        for (int i = 0; i < clientConnections.size(); ++i) {
            ConnectionThread cc = clientConnections.get(i);
            long x = cc.getId();
            if (x == id) {
                // -- remove it from the active threads list
                //    the thread will terminate itself
                clientConnections.remove(i);

                // -- place some text in the area to let the server operator know
                //    what is going on
                System.out.println("SERVER: connection closed for client id " + id + "\n");
                break;
            }
        }
    }

    private void listen() {
        try {
            // -- open the server socket
            serverSocket = new ServerSocket(getPort());

            // -- server runs until we manually shut it down
            while (true) {
                // -- block until a client comes along
                Socket socket = serverSocket.accept();

                // -- connection accepted, create a peer-to-peer socket
                //    between the server (thread) and client
                peerConnection(socket);
            }
        } catch (IOException e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

    public ConnectionThread getClientConnection(int connectionID) {
        return clientConnections.get(connectionID);
    }

    public void addUserSessionToValidSessions(int id) {
        validSessions.put(id, true);
    }

    public void removeUserSessionFromValidSessions(int id) {
        validSessions.remove(id);
    }

    public boolean isLoggedIn(int id) {
        try {
            return validSessions.get(id);
        }
        catch (NullPointerException e) {
            return false;
        }
    }

    public List<Integer> getAllValidSessions() {
        return new ArrayList<>(validSessions.keySet());
    }
}
