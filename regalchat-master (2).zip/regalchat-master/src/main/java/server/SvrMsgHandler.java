package server;

import message.*;
import server.database.JDBCStatements;
import server.mail.SendMail;

import java.io.IOException;
import java.sql.SQLException;

public class SvrMsgHandler {
    public static void handle(Message msg, ConnectionThread thread){
        msg.connectionID = thread.connectionID;
        switch (msg.type) {
            case LOGIN: handle((LoginMsg) msg, thread); break;
            case REGISTER_REQ: handle((RegisterMsg) msg, thread); break;
            case DISCONNECT: handle((DisconnectMsg) msg, thread); break;
            case RECOVERY_REQ: break;
            case ONETIMECHECK: break;
            default: System.out.println("Command not supported.");
        }
    }


    public static void handle(LoginMsg msg, ConnectionThread thread){
        String username = msg.getUsername();
        String password = msg.getPassword();
        boolean areCredentialsValid = Authenticate.areCredentialsValid(username, password);
        SysMsg sysMsg = new SysMsg(SysMsg.SysMsgType.LOGIN_RESP, areCredentialsValid);
        MessageActions.send(sysMsg, thread.dataOut);
        thread.userID = JDBCStatements.getUserIDfromUsername(username);
        if (areCredentialsValid) {
            thread.server.addUserSessionToValidSessions(thread.userID);
        }
        System.out.println(msg.type.name() + ": " + username + ", " + password + " @"
                + thread.getConnectionIPAddr());

    }

    public static void handle(RegisterMsg msg, ConnectionThread thread){
        String username = msg.getUsername();
        String email = msg.getEmail();
        String password1 = msg.getPassword1();
        String password2 = msg.getPassword2();
        System.out.println(msg.type.name() + ": " + username + ", " + email + ", " + password1 + ", "
                + password2 + " @" + thread.getConnectionIPAddr());
        boolean[] validRegFormat = ValidateFormat.registration(username, email, password1, password2);
        if (validRegFormat[0] && validRegFormat[1] && validRegFormat[2] && validRegFormat[3]) {
            System.out.println("Good format.");
            try {
                JDBCStatements.insertUser(username, email, password1);
                MessageActions.send(new SysMsg(SysMsg.SysMsgType.REGISTER_RESP, true), thread.dataOut);
                int oneTimeCode = 100000 + (int)(Math.random() * ((999999 - 100000) + 1));
                System.out.println(JDBCStatements.getUserIDfromUsername(username));
                JDBCStatements.updateOneTimeCode(JDBCStatements.getUserIDfromUsername(username), oneTimeCode);
                SendMail.sendOneTimeCode(username, oneTimeCode);
                MessageActions.send(new SysMsg(SysMsg.SysMsgType.ALERT, true,
                    "A one-time use code has been sent to your email address."), thread.dataOut);
                MessageActions.send(new SysMsg(SysMsg.SysMsgType.REGISTER_RESP, true), thread.dataOut);
            }
            catch (SQLException e) {
                MessageActions.send(new SysMsg(SysMsg.SysMsgType.REGISTER_RESP, false), thread.dataOut);
                e.printStackTrace();
            }
        } else {
            MessageActions.send(new SysMsg(SysMsg.SysMsgType.ALERT, false,
            "Your username must be between 4-32 characters (only a-z A-Z 0-9 permitted). \n" +
            "Your email address must be a valid email address. \n" +
            "Your password must be 8-32 characters in length, and include at least one lowercase, one uppercase, " +
             "one digit, and one special character (!@#$*).")
             ,thread.dataOut);
            System.out.println("Bad format: ");
            System.out.println("\t" + (!validRegFormat[0] ? "Bad Username" : "Good Username"));
            System.out.println("\t" + (!validRegFormat[1] ? "Bad Email" : "Good Email"));
            System.out.println("\t" + (!validRegFormat[2] ? "Bad Password" : "Good Password"));
            System.out.println("\t" + (!validRegFormat[3] ? "Passwords Unmatched" : "Passwords Matched"));
        }
    }

    public static void handle(LogoutMsg msg, ConnectionThread thread) {
        thread.server.removeUserSessionFromValidSessions(thread.userID);
    }

    public static void handle(DisconnectMsg msg, ConnectionThread thread) {
        thread.server.removeUserSessionFromValidSessions(thread.userID);
        try {
            thread.dataIn.close();
            thread.server.removeID(thread.connectionID);
            thread.go = false;
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
}