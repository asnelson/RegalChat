package server;

import message.Message;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class ConnectionThread extends Thread {
    boolean go;
    int connectionID;
    String connectionIPAddr;
    boolean isLoggedIn;
    int userID;

    // -- the main server (port listener) will supply the socket
    //    the thread (this class) will provide the I/O streams
    //    BufferedReader is used because it handles String objects
    //    whereas DataInputStream does not (primitive types only)
    ObjectInputStream dataIn;
    ObjectOutputStream dataOut;

    // -- this is a reference to the "parent" Server object
    //    it will be set at time of construction
    Server server;

    ConnectionThread(int connectionID, Socket socket, Server server) {
        this.server = server;
        this.connectionID = connectionID;
        this.connectionIPAddr = socket.getRemoteSocketAddress().toString();
        go = true;

        // -- create the stream I/O objects on top of the socket
        try {
            dataOut = new ObjectOutputStream(socket.getOutputStream());
            dataIn = new ObjectInputStream(socket.getInputStream());
        } catch (IOException e) {
            e.printStackTrace();
            System.exit(1);
        }

    }

    public int getConnectionID() {
        return connectionID;
    }

    public String getConnectionIPAddr() {
        return connectionIPAddr;
    }

    public void run() {
        // -- server thread runs until the client terminates the connection
        while (go) {
            try {
                Message msg = (Message) dataIn.readObject();
                SvrMsgHandler.handle(msg, this);
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
                go = false;
            }
        }
    }
}
