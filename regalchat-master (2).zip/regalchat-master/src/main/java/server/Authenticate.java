package server;

import server.database.JDBCOperations;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Authenticate {

    public static boolean areCredentialsValid(String username, String password){
        Statement statement = null;
        String query = "SELECT EXISTS(SELECT * FROM " + JDBCOperations.getDBName()
            + ".Users WHERE username='" + username + "' AND pass='" + password + "')";
        try {
            statement = Server.dbCon.createStatement();
            ResultSet rs = statement.executeQuery(query);
            rs.next();
            if(rs.getBoolean(1)) {
                return true;
            }
            else {
                return false;
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
