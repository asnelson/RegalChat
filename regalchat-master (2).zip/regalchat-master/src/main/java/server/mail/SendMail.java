package server.mail;

import server.database.JDBCStatements;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class SendMail {

    public static void sendOneTimeCode(String username, int oneTimeCode) {

        final String gmailUsername = "REDACTED";
        final String gmailPassword = "REDACTED";

        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        Session session = Session.getInstance(props,
                new javax.mail.Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(gmailUsername, gmailPassword);
                    }
                });


        try {

            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress("REDACTED@REDACTED"));
            System.out.println(JDBCStatements.getEmailAddr(1));
            JDBCStatements.getUserIDfromUsername("admin");
            message.setRecipients(Message.RecipientType.TO,
                    InternetAddress.parse(JDBCStatements.getEmailAddr(JDBCStatements.getUserIDfromUsername(username))));
            message.setSubject("[REGALCHAT] Your one-time use code.");
            message.setText("Your one-time use code is: " + oneTimeCode);

            Transport.send(message);

            System.out.println("Done");

        } catch (MessagingException e) {
            throw new RuntimeException(e);
        }

    }

    public static void main(String[] args) {

        final String username = "REDACTED";
        final String password = "REDACTED";

        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        Session session = Session.getInstance(props,
                new javax.mail.Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(username, password);
                    }
                });

    }
}
