package server.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class JDBCOperations {
    private final static String dbms = "mysql";
    private final static String serverName = "localhost";
    private final static String portNumber = "3306";
    private final static String username = "REDACTED";
    private final static String password = "REDACTED";
    private final static String dbName = "regalchat";

    public static java.sql.Connection getConnection() throws SQLException {
        Connection con;
        Properties connectionProps = new Properties();
        connectionProps.put("user", username);
        connectionProps.put("password", password);
        connectionProps.put("useSSL", "false");
        con = DriverManager.getConnection("jdbc:" + dbms + "://" + serverName + ":"
                + portNumber + "/" + dbName , connectionProps);
        System.out.println("Connected to database");
        return con;
    }

    public static String getDbms(){
        return dbms;
    }

    public static String getServerName(){
        return serverName;
    }

    public static String getPortNumber(){
        return portNumber;
    }

    public static String getDBName(){
        return dbName;
    }
}
