package server.database;

import server.Server;

import java.sql.*;

public class JDBCStatements {

    static Connection con = Server.dbCon;

    public static void insertUser(String username, String email, String password) throws SQLException {
        PreparedStatement insertUser = null;

        String insertString = "INSERT INTO " + JDBCOperations.getDBName() + ".Users(username, email, pass) VALUE (?, ?, ?)";

        try {
            con.setAutoCommit(false);
            insertUser = con.prepareStatement(insertString);
            insertUser.setString(1, username);
            insertUser.setString(2, email);
            insertUser.setString(3, password);
            System.out.println(insertUser.toString());
            insertUser.executeUpdate();
            con.commit();
            System.out.println("Record added.");
        } catch (SQLException e) {
            e.printStackTrace();
            handleSQLException();
        }
    }

    public static void updateOneTimeCode(int userID, int oneTimeCode) {
        PreparedStatement updateOneTimeCode;

        String updateString = "UPDATE Users SET oneTime=? WHERE userID=?";

        try {
            con.setAutoCommit(false);
            updateOneTimeCode = con.prepareStatement(updateString);
            updateOneTimeCode.setInt(1,oneTimeCode);
            updateOneTimeCode.setInt(2,userID);
            System.out.println(updateOneTimeCode.toString());
            updateOneTimeCode.executeUpdate();
            con.commit();
            System.out.println("Record added.");
        } catch (SQLException e) {
            e.printStackTrace();
            handleSQLException();
        }

    }

    private static void handleSQLException() {
        if (con != null) {
            try {
                System.err.print("Transaction is being rolled back");
                con.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    public static int getUserIDfromUsername(String username) {
        Statement statement;
        String query = "SELECT * FROM Users WHERE username='" + username + "'";
        try {
            statement = con.createStatement();
            ResultSet rs = statement.executeQuery(query);
            rs.next();
            return rs.getInt("userID");
        }
        catch (SQLException e) {
            return -1;
        }
    }

    public static String getEmailAddr(int userID) {
        Statement statement;
        String query = "SELECT * FROM Users WHERE userID=" + userID;
        try {
            statement = con.createStatement();
            ResultSet rs = statement.executeQuery(query);
            rs.next();
            return rs.getString("email");
        }
        catch (SQLException e) {
            return null;
        }
    }
}
