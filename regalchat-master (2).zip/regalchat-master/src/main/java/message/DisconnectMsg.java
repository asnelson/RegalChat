package message;

public class DisconnectMsg extends Message {
    MsgType type = MsgType.DISCONNECT;

    public DisconnectMsg() {
    }
}
