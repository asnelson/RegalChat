package message;

public class SysMsg extends Message {
    public enum SysMsgType {LOGIN_RESP, REGISTER_RESP, ALERT}
    public SysMsgType sysType;
    private boolean bool;
    private String text;

    public SysMsg(SysMsgType sysType, boolean bool, String text) {
        this.type = MsgType.SYSMSG;
        this.sysType = sysType;
        this.bool = bool;
        this.text = text;
    }

    public SysMsg(SysMsgType sysType, boolean bool) {
        this.type = MsgType.SYSMSG;
        this.sysType = sysType;
        this.bool = bool;
    }

    public boolean getBool() {
        return this.bool;
    }

    public String getText() {
        return this.text;
    }
}
