package message;

public class OneTimeCheckMsg extends Message {
    String email;
    String oneTimeCode;

    public OneTimeCheckMsg(String email, String oneTimeCode) {
        this.email = email;
        this.oneTimeCode = oneTimeCode;
    }
}
