package message;

public class LogoutMsg extends Message {

    public LogoutMsg() {
        this.type = MsgType.LOGOUT;
    }
}
