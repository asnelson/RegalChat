package message;

import java.io.IOException;
import java.io.ObjectOutputStream;

public class MessageActions {

    public static void send(Message msg, ObjectOutputStream dataOut) {
        try {
            dataOut.writeObject(msg);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
