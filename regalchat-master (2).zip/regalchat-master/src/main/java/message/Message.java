package message;

import java.io.Serializable;

public class Message implements Serializable {
    public MsgType type;
    public int connectionID;

    public enum MsgType {
        DISCONNECT, LOGIN, LOGOUT, REGISTER_REQ, RECOVERY_REQ, UPDATEACCT, CHATREQ, CHATMSG, MSGRECEIPT_REQ, SYSMSG,
        MSGRECEIPT_RESP, ONETIMECHECK
    }
}