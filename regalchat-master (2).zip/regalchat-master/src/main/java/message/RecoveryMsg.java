package message;

public class RecoveryMsg extends Message {
    String username;
    public RecoveryMsg(String username) {
        this.type = MsgType.RECOVERY_REQ;
        this.username = username;
    }
}