package client;

import client.login.LoginController;
import client.register.RegisterController;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import message.Message;
import message.SysMsg;

public class CliMsgHandler {
    static void handle(Message msg) {
        switch (msg.type) {
            case SYSMSG: handle((SysMsg)msg); break;
            default: System.out.println("Message format not supported.");
        }
    }
    public static void handle(SysMsg msg) {
        switch (msg.sysType) {
            case LOGIN_RESP: handleLoginResp(msg.getBool()); break;
            case REGISTER_RESP: break;
            case ALERT: handleAlert(msg.getText());
        }
    }

    public static void handleLoginResp(boolean authenticated) {
        LoginController.credentialsAuthenticated = authenticated;
        LoginController.waitingForLoginResp = false;
    }

    public static void handleRegisterResp(boolean registered) {
        RegisterController.credentialsRegistered = registered;
        RegisterController.waitingForRegisterResp = false;
    }

    public static void handleAlert(String text) {
        Alert alert = new Alert(Alert.AlertType.NONE, text, ButtonType.OK);
        alert.showAndWait();
    }
}