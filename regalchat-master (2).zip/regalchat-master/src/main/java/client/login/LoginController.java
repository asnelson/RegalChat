package client.login;

import client.ClientUI;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;
import message.LoginMsg;
import message.MessageActions;

import java.io.IOException;

public class LoginController {

    @FXML
    private TextField usernameField;
    @FXML
    private TextField passwordField;

    public static boolean waitingForLoginResp;
    public static boolean credentialsAuthenticated;

    @FXML
    public void loginButtonAction(ActionEvent event) throws IOException {
        String username = usernameField.getText();
        String password = passwordField.getText();
        LoginMsg msg = new LoginMsg(username, password);
        MessageActions.send(msg, ClientUI.client.dataOut);
        waitingForLoginResp = true;
        while(waitingForLoginResp) {
            ((Node) event.getSource()).getScene().setCursor(Cursor.WAIT);
        }
        System.out.println("Login response:" + credentialsAuthenticated);
        ((Node) event.getSource()).getScene().setCursor(Cursor.DEFAULT);
        if (credentialsAuthenticated) {
            ClientUI.changeScene(event, "/views/ChatView.fxml");
        }
        else {
            Alert alert = new Alert(Alert.AlertType.ERROR, "Your username and/or password are incorrect.",
                ButtonType.OK);
            alert.showAndWait();
        }

    }

    @FXML
    public void registerLinkAction(ActionEvent event) throws IOException {
        ClientUI.changeScene(event, "/views/RegisterView.fxml");
    }

    @FXML
    public void recoveryLinkAction(ActionEvent event) throws IOException {
        ClientUI.changeScene(event, "/views/RecoveryView.fxml");
    }
}