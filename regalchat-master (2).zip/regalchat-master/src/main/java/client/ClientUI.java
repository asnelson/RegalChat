package client;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;
import java.lang.invoke.MethodHandles;

public class ClientUI extends Application {

    static final String appName = "RegalChat Client";
    static final String versionNumber = "0.1";
    public static Client client;
    protected static Stage primaryStage;

    public static void changeScene(ActionEvent event, String view) throws IOException {
        FXMLLoader fmxlLoader = new FXMLLoader(MethodHandles.lookup().lookupClass().getResource(view));
        Parent window = fmxlLoader.load();
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(new Pane(window)));
    }

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws IOException {
        this.primaryStage = primaryStage;
        Parent root = FXMLLoader.load(getClass().getResource("/views/LoginView.fxml"));
        primaryStage.setTitle(appName + " v" + versionNumber + " @ " + client.HOST + ":" + client.PORT);
        Scene mainScene = new Scene(root, 640, 480);
        setUserAgentStylesheet(STYLESHEET_MODENA);
        mainScene.setRoot(root);
        primaryStage.setResizable(false);
        primaryStage.setScene(mainScene);
        primaryStage.show();
        client = new Client();
    }
}