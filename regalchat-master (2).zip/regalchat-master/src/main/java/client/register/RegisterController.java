package client.register;

import client.ClientUI;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;
import message.MessageActions;
import message.RegisterMsg;

import java.io.IOException;

public class RegisterController {
    @FXML
    private TextField usernameField;
    @FXML
    private TextField emailField;
    @FXML
    private TextField password1Field;
    @FXML
    private TextField password2Field;

    public static boolean waitingForRegisterResp;
    public static boolean credentialsRegistered;

    @FXML
    public void registerButtonAction(ActionEvent event) throws IOException {
        String username = usernameField.getText();
        String email = emailField.getText();
        String password1 = password1Field.getText();
        String password2 = password2Field.getText();
        RegisterMsg msg = new RegisterMsg(username, email, password1, password2);
        MessageActions.send(msg, ClientUI.client.dataOut);
        waitingForRegisterResp = true;
        while (waitingForRegisterResp) {
            ((Node) event.getSource()).getScene().setCursor(Cursor.WAIT);
        }
        System.out.println("Register response:" + credentialsRegistered);
        ((Node) event.getSource()).getScene().setCursor(Cursor.DEFAULT);
        if (credentialsRegistered) {
            ClientUI.changeScene(event, "/views/RecoveryView.fxml");
        }
        else {
            Alert alert = new Alert(Alert.AlertType.ERROR,
            "Your username must be between 4-32 characters (only a-z A-Z 0-9 permitted). \n" +
            "Your email address must be a valid email address. \n" +
            "Your password must be 8-32 characters in length, and include at least one lowercase, one uppercase, " +
             "one digit, and one special character (!@#$*).",
             ButtonType.OK);
            alert.showAndWait();
        }
    }

}