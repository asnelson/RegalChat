package client.chat;

import client.ClientUI;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import message.DisconnectMsg;
import message.LogoutMsg;
import message.MessageActions;

import java.io.IOException;

public class ChatController {

    public void logoutMenuAction(ActionEvent event) throws IOException {
        MessageActions.send(new LogoutMsg(), ClientUI.client.dataOut);
        ClientUI.changeScene(event, "/views/LoginView.fxml");
    }

    public void aboutMenuAction(ActionEvent event) {
    }

    public void settingsMenuAction(ActionEvent event) {
    }
}