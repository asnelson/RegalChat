package client;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

public class Client {

    // -- port and host name of server
    static final int PORT = 8000;

    /*
     From ipconfig:

     Wireless LAN adapter Wireless Network Connection:

     Connection-specific DNS Suffix  . : clunet.edu
     Link-local IPv6 Address . . . . . : fe80::1083:3e22:f5a1:a3ec%11
     IPv4 Address. . . . . . . . . . . : 199.107.222.115 <=======This address works
     Subnet Mask . . . . . . . . . . . : 255.255.240.0
     Default Gateway . . . . . . . . . : 199.107.210.2
     */
    static final String HOST = "localhost";//"199.107.222.115";//"localhost";//"127.0.0.1";
    // -- the actual host IP address of the machine can
    //    be found using ipconfig from a command console
    // private final String HOST = "192.168.20.4";
    // -- stream variables for peer to peer communication
    //    to be opened on top of the socket
    public static ObjectOutputStream dataOut;
    // -- socket variable for peer to peer communication
    protected static Socket socket;

    Client() {
        try {
            // -- construct the peer to peer socket
            socket = new Socket(HOST, PORT);
            // -- wrap the socket in stream I/O objects
            dataOut = new ObjectOutputStream(socket.getOutputStream());
            Thread listenerThread = new Thread(new ClientListener());
            listenerThread.start();
        } catch (UnknownHostException e) {
            System.out.println("Host " + HOST + " at port " + PORT + " is unavailable.");
            System.exit(1);
        } catch (IOException e) {
            System.out.println("Unable to create I/O streams.");
            System.exit(1);
        }
    }
}
