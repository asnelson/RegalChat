package client.settings;

public class SettingsController {
    public void saveButtonAction() {
    }
}
