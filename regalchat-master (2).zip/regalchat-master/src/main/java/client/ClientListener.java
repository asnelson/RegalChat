package client;

import message.Message;

import java.io.IOException;
import java.io.ObjectInputStream;

public class ClientListener implements Runnable {
    private static ObjectInputStream dataIn;

    ClientListener() throws IOException {
        this.dataIn = new ObjectInputStream(Client.socket.getInputStream());
    }

    public void run(){
        try {
            while(true) {
                Message msg = (Message) dataIn.readObject();
                CliMsgHandler.handle(msg);
            }
        }
        catch (IOException | ClassNotFoundException e) {

        }
    }
}
