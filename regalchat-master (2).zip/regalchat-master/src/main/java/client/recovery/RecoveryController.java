package client.recovery;

import client.ClientUI;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import message.MessageActions;
import message.OneTimeCheckMsg;
import message.RecoveryMsg;

public class RecoveryController {

    @FXML
    private TextField usernameField;
    @FXML
    private TextField emailField;
    @FXML
    private TextField oneTimeField;

    @FXML
    public void sendRecoveryCodeButtonAction() {
        MessageActions.send(new RecoveryMsg(usernameField.getText()), ClientUI.client.dataOut);
    }

    @FXML
    public void recoveryCodeButtonAction() {
        MessageActions.send(new OneTimeCheckMsg(emailField.getText(), oneTimeField.getText()), ClientUI.client.dataOut);
    }
}
